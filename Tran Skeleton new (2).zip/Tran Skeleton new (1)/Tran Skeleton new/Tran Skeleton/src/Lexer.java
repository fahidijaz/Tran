import java.util.LinkedList;
import java.util.List;

public class Lexer {
    private final TextManager textManager;
    private final LinkedList<Token> tokens;
    private int currentIndentLevel = 0;
    private final LinkedList<Integer> indentStack = new LinkedList<>();
    private int line = 1;
    private int charPosition = 0;

    private int baseIndentationLevel = -1;  // NEW: Base indentation level

    // Add all keywords
    private static final String[] KEYWORDS = {
            "accessor", "mutator", "if", "else", "while", "return", "class", "interface", "loop",
            "construct", "implements", "and", "or", "not", "true", "false", "new", "private", "shared"
    };

    private static final int INDENT_LEVEL = 4;

    public Lexer(String input) {
        this.textManager = new TextManager(input);
        this.tokens = new LinkedList<>();
        indentStack.push(0);
    }

    public List<Token> Lex() throws SyntaxErrorException {
        // Skip any leading whitespace and newlines before the first non-whitespace character
        while (!textManager.isAtEnd() &&
                (textManager.peekCharacter() == ' ' ||
                        textManager.peekCharacter() == '\t' ||
                        textManager.peekCharacter() == '\n')) {
            if (textManager.peekCharacter() == '\n') {
                line++;
                charPosition = 0;
            } else {
                charPosition++;
            }
            textManager.getCharacter();
        }

        // Set baseIndentationLevel to zero
        baseIndentationLevel = 0;
        currentIndentLevel = 0;

        // Proceed with lexing as normal
        while (!textManager.isAtEnd()) {
            char currentChar = textManager.peekCharacter();

            if (currentChar == '\n') {
                tokens.add(new Token(Token.TokenTypes.NEWLINE, line, charPosition));
                textManager.getCharacter();  // Consume '\n'
                charPosition = 0;
                line++;
                handleIndentation();  // Handle indentation after newline
                continue;
            }

            if (Character.isWhitespace(currentChar)) {
                if (charPosition == 0) {
                    handleIndentation();
                } else {
                    handleWhitespace();
                }
                continue;
            }

            if (currentChar == '{') {
                handleComment();
            } else if (currentChar == '\"') {
                handleString();
            } else if (Character.isLetter(currentChar)) {
                tokens.add(parseWord());
            } else if (Character.isDigit(currentChar)) {
                tokens.add(parseNumber());
            } else {
                tokens.add(parsePunctuation());
            }

            // Skip any trailing whitespace
            while (!textManager.isAtEnd() &&
                    (textManager.peekCharacter() == ' ' || textManager.peekCharacter() == '\t')) {
                textManager.getCharacter();
                charPosition++;
            }
        }

        // Handle remaining dedents at the end of the file
        while (currentIndentLevel > 0) {
            tokens.add(new Token(Token.TokenTypes.DEDENT, line, charPosition));
            currentIndentLevel--;
        }

        return tokens;
    }



    private void handleIndentation() throws SyntaxErrorException {
        int indentCount = 0;
        int startPosition = charPosition;

        // Count the number of spaces and tabs for the new indentation level
        while (!textManager.isAtEnd() &&
                (textManager.peekCharacter() == ' ' || textManager.peekCharacter() == '\t')) {
            char currentChar = textManager.getCharacter();
            charPosition++;
            if (currentChar == ' ') {
                indentCount++;
            } else if (currentChar == '\t') {
                indentCount += INDENT_LEVEL;
            }
        }

        // Check if the line is empty (only NEWLINE after indentation)
        if (textManager.isAtEnd() || textManager.peekCharacter() == '\n') {
            // Do not adjust indentation levels for empty lines
            return;
        }

        // Ensure the indentation level is valid (multiple of INDENT_LEVEL)
        if (indentCount % INDENT_LEVEL != 0) {
            throw new SyntaxErrorException("Invalid indentation level", line, charPosition);
        }

        int newIndentLevel = indentCount / INDENT_LEVEL;

        // Handle increase in indentation
        if (newIndentLevel > currentIndentLevel) {
            while (currentIndentLevel < newIndentLevel) {
                tokens.add(new Token(Token.TokenTypes.INDENT, line, startPosition));
                currentIndentLevel++;
            }
        }
        // Handle decrease in indentation
        else if (newIndentLevel < currentIndentLevel) {
            while (currentIndentLevel > newIndentLevel) {
                tokens.add(new Token(Token.TokenTypes.DEDENT, line, startPosition));
                currentIndentLevel--;
            }
        }
    }


    private void handleWhitespace() {
        while (!textManager.isAtEnd() && Character.isWhitespace(textManager.peekCharacter()) && textManager.peekCharacter() != '\n') {
            textManager.getCharacter();
            charPosition++;
        }
    }

    private void handleComment() throws SyntaxErrorException {
        textManager.getCharacter();
        charPosition++;
        while (!textManager.isAtEnd() && textManager.peekCharacter() != '}') {
            if (textManager.peekCharacter() == '\n') {
                line++;
                charPosition = 0;
            }
            textManager.getCharacter();
            charPosition++;
        }
        if (textManager.isAtEnd()) {
            throw new SyntaxErrorException("Unterminated comment", line, charPosition);
        }
        textManager.getCharacter();
        charPosition++;
    }

    private void handleString() throws SyntaxErrorException {
        StringBuilder sb = new StringBuilder();
        int startColumn = charPosition;
        textManager.getCharacter();
        charPosition++;
        while (!textManager.isAtEnd() && textManager.peekCharacter() != '\"') {
            sb.append(textManager.getCharacter());
            charPosition++;
        }
        if (textManager.isAtEnd()) {
            throw new SyntaxErrorException("Unterminated string literal", line, charPosition);
        }
        textManager.getCharacter();
        charPosition++;
        tokens.add(new Token(Token.TokenTypes.QUOTEDSTRING, line, startColumn, sb.toString()));
    }

    private Token parseWord() throws SyntaxErrorException {
        StringBuilder sb = new StringBuilder();
        int startColumn = charPosition;
        while (!textManager.isAtEnd() && (Character.isLetterOrDigit(textManager.peekCharacter()) || textManager.peekCharacter() == '_')) {
            sb.append(textManager.getCharacter());
            charPosition++;
        }

        String word = sb.toString();

        // Check if the word is a keyword
        Token.TokenTypes type;
        switch (word) {
            case "accessor":
                type = Token.TokenTypes.ACCESSOR;
                break;
            case "mutator":
                type = Token.TokenTypes.MUTATOR;
                break;
            case "if":
                type = Token.TokenTypes.IF;
                break;
            case "else":
                type = Token.TokenTypes.ELSE;
                break;
            case "class":
                type = Token.TokenTypes.CLASS;
                break;
            case "interface":
                type = Token.TokenTypes.INTERFACE;
                break;
            case "loop":
                type = Token.TokenTypes.LOOP;
                break;
            case "construct":
                type = Token.TokenTypes.CONSTRUCT;
                break;
            case "implements":
                type = Token.TokenTypes.IMPLEMENTS;
                break;
            case "and":
                type = Token.TokenTypes.AND;
                break;
            case "or":
                type = Token.TokenTypes.OR;
                break;
            case "not":
                type = Token.TokenTypes.NOT;
                break;
            case "true":
                type = Token.TokenTypes.TRUE;
                break;
            case "false":
                type = Token.TokenTypes.FALSE;
                break;
            case "new":
                type = Token.TokenTypes.NEW;
                break;
            case "private":
                type = Token.TokenTypes.PRIVATE;
                break;
            case "shared":
                type = Token.TokenTypes.SHARED;
                break;
            default:
                type = Token.TokenTypes.WORD;
                break;
        }

        if (type == Token.TokenTypes.WORD || type == Token.TokenTypes.NUMBER || type == Token.TokenTypes.QUOTEDSTRING) {
            return new Token(type, line, startColumn, word);
        } else {
            return new Token(type, line, startColumn);
        }
    }

    private Token parseNumber() throws SyntaxErrorException {
        StringBuilder sb = new StringBuilder();
        int startColumn = charPosition;
        boolean seenDot = false;
        while (!textManager.isAtEnd() && (Character.isDigit(textManager.peekCharacter()) || textManager.peekCharacter() == '.')) {
            if (textManager.peekCharacter() == '.') {
                if (seenDot) {
                    throw new SyntaxErrorException("Unexpected '.'", line, charPosition);
                }
                seenDot = true;
            }
            sb.append(textManager.getCharacter());
            charPosition++;
        }
        return new Token(Token.TokenTypes.NUMBER, line, startColumn, sb.toString());
    }

    private Token parsePunctuation() throws SyntaxErrorException {
        char punctuation = textManager.getCharacter();
        charPosition++;
        Token.TokenTypes type;

        switch (punctuation) {
            case '=':
                if (textManager.peekCharacter() == '=') {
                    textManager.getCharacter();
                    charPosition++;
                    type = Token.TokenTypes.EQUAL;
                } else {
                    type = Token.TokenTypes.ASSIGN;
                }
                break;
            case '!':
                if (textManager.peekCharacter() == '=') {
                    textManager.getCharacter();
                    charPosition++;
                    type = Token.TokenTypes.NOTEQUAL;
                } else {
                    throw new SyntaxErrorException("Unexpected character: " + punctuation, line, charPosition);
                }
                break;
            case '<':
                if (textManager.peekCharacter() == '=') {
                    textManager.getCharacter();
                    charPosition++;
                    type = Token.TokenTypes.LESSTHANEQUAL;
                } else {
                    type = Token.TokenTypes.LESSTHAN;
                }
                break;
            case '>':
                if (textManager.peekCharacter() == '=') {
                    textManager.getCharacter();  // Consume '='
                    charPosition++;
                    type = Token.TokenTypes.GREATERTHANEQUAL;
                } else {
                    type = Token.TokenTypes.GREATERTHAN;
                }
                break;
            case '&':
                if (textManager.peekCharacter() == '&') {
                    textManager.getCharacter();  // Consume second '&'
                    charPosition++;
                    type = Token.TokenTypes.AND;
                } else {
                    throw new SyntaxErrorException("Unexpected character: " + punctuation, line, charPosition);
                }
                break;
            case '|':
                if (textManager.peekCharacter() == '|') {
                    textManager.getCharacter();  // Consume second '|'
                    charPosition++;
                    type = Token.TokenTypes.OR;
                } else {
                    throw new SyntaxErrorException("Unexpected character: " + punctuation, line, charPosition);
                }
                break;
            case '(':
                type = Token.TokenTypes.LPAREN;
                break;
            case ')':
                type = Token.TokenTypes.RPAREN;
                break;
            case ':':
                type = Token.TokenTypes.COLON;
                break;
            case '.':
                type = Token.TokenTypes.DOT;
                break;
            case '+':
                type = Token.TokenTypes.PLUS;
                break;
            case '-':
                type = Token.TokenTypes.MINUS;
                break;
            case '*':
                type = Token.TokenTypes.TIMES;
                break;
            case '/':
                type = Token.TokenTypes.DIVIDE;
                break;
            case '%':
                type = Token.TokenTypes.MODULO;
                break;
            case ',':
                type = Token.TokenTypes.COMMA;
                break;
            default:
                throw new SyntaxErrorException("Unexpected character: " + punctuation, line, charPosition);
        }

        return new Token(type, line, charPosition);
    }
}
