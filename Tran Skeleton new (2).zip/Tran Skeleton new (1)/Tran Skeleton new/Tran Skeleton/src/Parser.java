import AST.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Parser {

    private TokenManager tokenManager;
    private TranNode tranNode;

    public Parser(TranNode tranNode, List<Token> tokens) {
        this.tranNode = tranNode;
        this.tokenManager = new TokenManager(tokens);
    }

    public void Tran() throws SyntaxErrorException {
        while (!tokenManager.done()) {
            // Skip over NEWLINE, INDENT, and DEDENT tokens
            while (tokenManager.peek(0).isPresent() &&
                    (tokenManager.peek(0).get().getType() == Token.TokenTypes.NEWLINE ||
                            tokenManager.peek(0).get().getType() == Token.TokenTypes.INDENT ||
                            tokenManager.peek(0).get().getType() == Token.TokenTypes.DEDENT)) {
                tokenManager.matchAndRemove(tokenManager.peek(0).get().getType());
            }

            if (tokenManager.done()) {
                break;
            }

            Token.TokenTypes tokenType = tokenManager.peek(0).get().getType();
            if (tokenType == Token.TokenTypes.CLASS) {
                Class();
            } else if (tokenType == Token.TokenTypes.INTERFACE) {
                Interface();
            } else {
                throw new SyntaxErrorException("Expected 'class' or 'interface'",
                        tokenManager.peek(0).get().getLineNumber(),
                        tokenManager.peek(0).get().getColumnNumber());
            }
        }
    }


    private void RequireNewLine() throws SyntaxErrorException {
        tokenManager.matchAndRemove(Token.TokenTypes.NEWLINE)
                .orElseThrow(() -> new SyntaxErrorException("Expected NEWLINE",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));
    }

    // New method to skip multiple NEWLINEs
    private void SkipNewLines() throws SyntaxErrorException {
        while (tokenManager.peek(0).isPresent() &&
                tokenManager.peek(0).get().getType() == Token.TokenTypes.NEWLINE) {
            tokenManager.matchAndRemove(Token.TokenTypes.NEWLINE);
        }
    }

    private void RequireColon() throws SyntaxErrorException {
        tokenManager.matchAndRemove(Token.TokenTypes.COLON)
                .orElseThrow(() -> new SyntaxErrorException("Expected ':'",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));
    }

    // Parsing Class
    // Parsing Class
    private ClassNode Class() throws SyntaxErrorException {
        tokenManager.matchAndRemove(Token.TokenTypes.CLASS);  // Match 'class' keyword
        Token nameToken = tokenManager.matchAndRemove(Token.TokenTypes.WORD)
                .orElseThrow(() -> new SyntaxErrorException("Expected class name",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));
        String className = nameToken.getValue();

        ClassNode classNode = new ClassNode();
        classNode.name = className;

        if (tokenManager.peek(0).isPresent()) {
            Token nextToken = tokenManager.peek(0).get();
            if (nextToken.getType() == Token.TokenTypes.IMPLEMENTS) {

                tokenManager.matchAndRemove(Token.TokenTypes.IMPLEMENTS);

                // Process the list of interfaces
                while (true) {
                    Token interfaceNameToken = tokenManager.matchAndRemove(Token.TokenTypes.WORD)
                            .orElseThrow(() -> new SyntaxErrorException("Expected interface name",
                                    tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                                    tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));
                    classNode.interfaces.add(interfaceNameToken.getValue());

                    if (tokenManager.peek(0).isPresent() && tokenManager.peek(0).get().getType() == Token.TokenTypes.COMMA) {
                        tokenManager.matchAndRemove(Token.TokenTypes.COMMA);
                    } else {
                        break;
                    }
                }
            } else if (nextToken.getType() == Token.TokenTypes.NEWLINE) {
                // No action needed; we'll handle multiple NEWLINEs next
            } else {
                throw new SyntaxErrorException("Expected 'implements' or NEWLINE after class name",
                        nextToken.getLineNumber(),
                        nextToken.getColumnNumber());
            }
        } else {
            throw new SyntaxErrorException("Unexpected end of input after class name",
                    nameToken.getLineNumber(),
                    nameToken.getColumnNumber());
        }

        // Use SkipNewLines() instead of RequireNewLine()
        SkipNewLines();

        tokenManager.matchAndRemove(Token.TokenTypes.INDENT)
                .orElseThrow(() -> new SyntaxErrorException("Expected INDENT after class declaration",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        // Parse class body
        while (true) {
            if (tokenManager.peek(0).isPresent()) {
                Token.TokenTypes nextTokenType = tokenManager.peek(0).get().getType();

                if (nextTokenType == Token.TokenTypes.DEDENT) {
                    break;  // End of class body
                } else if (nextTokenType == Token.TokenTypes.NEWLINE) {
                    tokenManager.matchAndRemove(Token.TokenTypes.NEWLINE);
                } else if (nextTokenType == Token.TokenTypes.WORD) {
                    Optional<Token> secondToken = tokenManager.peek(1);
                    if (secondToken.isPresent() && secondToken.get().getType() == Token.TokenTypes.WORD) {
                        // Variable declaration
                        MemberNode member = MemberDeclaration();
                        classNode.members.add(member);
                    } else if (secondToken.isPresent() && secondToken.get().getType() == Token.TokenTypes.LPAREN) {
                        // Method declaration
                        MethodDeclarationNode methodNode = MethodDeclaration(false); // Not shared
                        classNode.methods.add(methodNode);
                    } else {
                        throw new SyntaxErrorException("Unexpected token in class body",
                                tokenManager.peek(0).get().getLineNumber(),
                                tokenManager.peek(0).get().getColumnNumber());
                    }
                } else if (nextTokenType == Token.TokenTypes.SHARED) {
                    // Handle 'SHARED' keyword
                    tokenManager.matchAndRemove(Token.TokenTypes.SHARED);
                    MethodDeclarationNode methodNode = MethodDeclaration(true); // Shared method
                    classNode.methods.add(methodNode);
                } else if (nextTokenType == Token.TokenTypes.CONSTRUCT) {
                    ConstructorNode constructorNode = ConstructorDeclaration();
                    classNode.constructors.add(constructorNode);
                } else {
                    throw new SyntaxErrorException("Unexpected token in class body",
                            tokenManager.peek(0).get().getLineNumber(),
                            tokenManager.peek(0).get().getColumnNumber());
                }
            } else {
                break;
            }
        }

        tokenManager.matchAndRemove(Token.TokenTypes.DEDENT)
                .orElseThrow(() -> new SyntaxErrorException("Expected DEDENT after class body",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        tranNode.Classes.add(classNode);
        return classNode;
    }

    // Parsing Member Declarations
    private MemberNode MemberDeclaration() throws SyntaxErrorException {
        VariableDeclarationNode variable = VariableDeclaration();

        MemberNode memberNode = new MemberNode();
        memberNode.declaration = variable;

        if (tokenManager.peek(0).isPresent() && tokenManager.peek(0).get().getType() == Token.TokenTypes.NEWLINE) {
            tokenManager.matchAndRemove(Token.TokenTypes.NEWLINE);
        }

        if (tokenManager.peek(0).isPresent() && tokenManager.peek(0).get().getType() == Token.TokenTypes.INDENT) {
            tokenManager.matchAndRemove(Token.TokenTypes.INDENT);

            while (true) {
                if (!tokenManager.peek(0).isPresent()) {
                    break;
                }

                Token.TokenTypes nextTokenType = tokenManager.peek(0).get().getType();

                if (nextTokenType == Token.TokenTypes.ACCESSOR || nextTokenType == Token.TokenTypes.MUTATOR) {
                    memberNode = parseAccessorMutator(memberNode);
                } else if (nextTokenType == Token.TokenTypes.NEWLINE) {
                    tokenManager.matchAndRemove(Token.TokenTypes.NEWLINE);
                } else {
                    break; // Exit loop if unexpected token
                }
            }

            tokenManager.matchAndRemove(Token.TokenTypes.DEDENT)
                    .orElseThrow(() -> new SyntaxErrorException("Expected DEDENT after accessor/mutator block",
                            tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                            tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));
        }

        return memberNode;
    }

    private MemberNode parseAccessorMutator(MemberNode memberNode) throws SyntaxErrorException {
        Token nextToken = tokenManager.peek(0).get();
        Token.TokenTypes accessorMutatorType = nextToken.getType();
        tokenManager.matchAndRemove(accessorMutatorType);
        RequireColon();

        // Skip over NEWLINE tokens
        while (tokenManager.peek(0).isPresent() &&
                tokenManager.peek(0).get().getType() == Token.TokenTypes.NEWLINE) {
            tokenManager.matchAndRemove(Token.TokenTypes.NEWLINE);
        }

        Optional<Token> nextTokenOpt = tokenManager.peek(0);
        List<StatementNode> statements = new ArrayList<>();
        if (nextTokenOpt.isPresent()) {
            Token.TokenTypes nextTokenType = nextTokenOpt.get().getType();
            if (nextTokenType == Token.TokenTypes.INDENT) {
                tokenManager.matchAndRemove(Token.TokenTypes.INDENT);
                statements = Statements();
                tokenManager.matchAndRemove(Token.TokenTypes.DEDENT)
                        .orElseThrow(() -> new SyntaxErrorException("Expected DEDENT after accessor/mutator body",
                                nextTokenOpt.get().getLineNumber(),
                                nextTokenOpt.get().getColumnNumber()));
            } else if (nextTokenType == Token.TokenTypes.DEDENT || nextTokenType == Token.TokenTypes.ACCESSOR ||
                    nextTokenType == Token.TokenTypes.MUTATOR || nextTokenType == Token.TokenTypes.NEWLINE) {

            } else {
                throw new SyntaxErrorException("Unexpected token after accessor/mutator declaration",
                        nextTokenOpt.get().getLineNumber(),
                        nextTokenOpt.get().getColumnNumber());
            }
        }

        if (accessorMutatorType == Token.TokenTypes.ACCESSOR) {
            memberNode.accessor = Optional.of(statements);
        } else {
            memberNode.mutator = Optional.of(statements);
        }

        return memberNode;
    }

    // Parsing Variable Declarations
    private VariableDeclarationNode VariableDeclaration() throws SyntaxErrorException {
        Token typeToken = tokenManager.matchAndRemove(Token.TokenTypes.WORD)
                .orElseThrow(() -> new SyntaxErrorException("Expected type",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        Token varNameToken = tokenManager.matchAndRemove(Token.TokenTypes.WORD)
                .orElseThrow(() -> new SyntaxErrorException("Expected variable name",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        VariableDeclarationNode variable = new VariableDeclarationNode();
        variable.type = typeToken.getValue();
        variable.name = varNameToken.getValue();

        return variable;
    }

    // Parsing Constructor Declarations
    private ConstructorNode ConstructorDeclaration() throws SyntaxErrorException {
        tokenManager.matchAndRemove(Token.TokenTypes.CONSTRUCT)
                .orElseThrow(() -> new SyntaxErrorException("Expected 'construct'",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        tokenManager.matchAndRemove(Token.TokenTypes.LPAREN)
                .orElseThrow(() -> new SyntaxErrorException("Expected '(' after 'construct'",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        tokenManager.matchAndRemove(Token.TokenTypes.RPAREN)
                .orElseThrow(() -> new SyntaxErrorException("Expected ')' after '('",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        RequireNewLine();

        tokenManager.matchAndRemove(Token.TokenTypes.INDENT)
                .orElseThrow(() -> new SyntaxErrorException("Expected INDENT to start constructor body",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        ConstructorNode constructorNode = new ConstructorNode();
        constructorNode.locals = new ArrayList<>();
        constructorNode.statements = new ArrayList<>();

        parseMethodOrConstructorBody(constructorNode.locals, constructorNode.statements);

        tokenManager.matchAndRemove(Token.TokenTypes.DEDENT)
                .orElseThrow(() -> new SyntaxErrorException("Expected DEDENT at end of constructor body",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        return constructorNode;
    }

    // Parsing Method Declarations
    // Parsing Method Declarations
    private MethodDeclarationNode MethodDeclaration(boolean isShared) throws SyntaxErrorException {
        MethodHeaderNode methodHeader = MethodHeader();

        MethodDeclarationNode methodDeclarationNode = new MethodDeclarationNode();
        methodDeclarationNode.name = methodHeader.name;
        methodDeclarationNode.parameters = methodHeader.parameters;
        methodDeclarationNode.returns = methodHeader.returns;
        methodDeclarationNode.locals = new ArrayList<>();
        methodDeclarationNode.statements = new ArrayList<>();
        methodDeclarationNode.isShared = isShared; // Set the shared flag

        RequireNewLine();

        tokenManager.matchAndRemove(Token.TokenTypes.INDENT)
                .orElseThrow(() -> new SyntaxErrorException("Expected INDENT to start method body",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        parseMethodOrConstructorBody(methodDeclarationNode.locals, methodDeclarationNode.statements);

        tokenManager.matchAndRemove(Token.TokenTypes.DEDENT)
                .orElseThrow(() -> new SyntaxErrorException("Expected DEDENT at end of method body",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        return methodDeclarationNode;
    }

    // Overloaded MethodDeclaration without parameters (for non-shared methods)
    private MethodDeclarationNode MethodDeclaration() throws SyntaxErrorException {
        return MethodDeclaration(false);
    }


    // Parsing Method Headers
    // Parsing Method Headers
    private MethodHeaderNode MethodHeader() throws SyntaxErrorException {
        Token methodNameToken = tokenManager.matchAndRemove(Token.TokenTypes.WORD)
                .orElseThrow(() -> new SyntaxErrorException("Expected method name",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));
        String methodName = methodNameToken.getValue();

        tokenManager.matchAndRemove(Token.TokenTypes.LPAREN)
                .orElseThrow(() -> new SyntaxErrorException("Expected '(' after method name",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        tokenManager.matchAndRemove(Token.TokenTypes.RPAREN)
                .orElseThrow(() -> new SyntaxErrorException("Expected ')' after '('",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        MethodHeaderNode methodHeaderNode = new MethodHeaderNode();
        methodHeaderNode.name = methodName;

        if (tokenManager.peek(0).isPresent() && tokenManager.peek(0).get().getType() == Token.TokenTypes.COLON) {
            tokenManager.matchAndRemove(Token.TokenTypes.COLON);

            methodHeaderNode.returns = ParameterList();
        }

        return methodHeaderNode;
    }


    // Parsing Parameter List
    private List<VariableDeclarationNode> ParameterList() throws SyntaxErrorException {
        List<VariableDeclarationNode> parameters = new ArrayList<>();

        while (true) {
            Token typeToken = tokenManager.matchAndRemove(Token.TokenTypes.WORD)
                    .orElseThrow(() -> new SyntaxErrorException("Expected type in parameter list",
                            tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                            tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

            Token nameToken = tokenManager.matchAndRemove(Token.TokenTypes.WORD)
                    .orElseThrow(() -> new SyntaxErrorException("Expected variable name in parameter list",
                            tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                            tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

            VariableDeclarationNode parameter = new VariableDeclarationNode();
            parameter.type = typeToken.getValue();
            parameter.name = nameToken.getValue();
            parameters.add(parameter);

            if (tokenManager.peek(0).isPresent() && tokenManager.peek(0).get().getType() == Token.TokenTypes.COMMA) {
                tokenManager.matchAndRemove(Token.TokenTypes.COMMA);
            } else {
                break;
            }
        }

        return parameters;
    }

    // Parsing Interface
    private InterfaceNode Interface() throws SyntaxErrorException {
        tokenManager.matchAndRemove(Token.TokenTypes.INTERFACE);

        Token nameToken = tokenManager.matchAndRemove(Token.TokenTypes.WORD)
                .orElseThrow(() -> new SyntaxErrorException("Expected interface name",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));
        String interfaceName = nameToken.getValue();

        InterfaceNode interfaceNode = new InterfaceNode();
        interfaceNode.name = interfaceName;

        RequireNewLine();
        tokenManager.matchAndRemove(Token.TokenTypes.INDENT)
                .orElseThrow(() -> new SyntaxErrorException("Expected INDENT after interface declaration",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        while (true) {
            if (tokenManager.peek(0).isPresent()) {
                Token.TokenTypes nextTokenType = tokenManager.peek(0).get().getType();

                if (nextTokenType == Token.TokenTypes.DEDENT) {
                    break;
                }

                MethodHeaderNode methodHeader = MethodHeader();
                interfaceNode.methods.add(methodHeader);

                if (tokenManager.peek(0).isPresent()) {
                    nextTokenType = tokenManager.peek(0).get().getType();
                    if (nextTokenType == Token.TokenTypes.NEWLINE) {
                        tokenManager.matchAndRemove(Token.TokenTypes.NEWLINE);
                    } else if (nextTokenType == Token.TokenTypes.DEDENT) {
                        break;
                    } else {
                        throw new SyntaxErrorException("Expected NEWLINE or DEDENT after method header in interface",
                                tokenManager.peek(0).get().getLineNumber(),
                                tokenManager.peek(0).get().getColumnNumber());
                    }
                } else {
                    break;
                }
            } else {
                break;
            }
        }

        tokenManager.matchAndRemove(Token.TokenTypes.DEDENT)
                .orElseThrow(() -> new SyntaxErrorException("Expected DEDENT after interface body",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        tranNode.Interfaces.add(interfaceNode);
        return interfaceNode;
    }

    // Parsing Statements
    private List<StatementNode> Statements() throws SyntaxErrorException {
        List<StatementNode> statements = new ArrayList<>();

        while (tokenManager.peek(0).isPresent()
                && tokenManager.peek(0).get().getType() != Token.TokenTypes.DEDENT) {
            StatementNode statement = Statement();
            if (statement != null) {
                statements.add(statement);
            }
        }
        return statements;
    }

    private StatementNode Statement() throws SyntaxErrorException {
        Token.TokenTypes nextTokenType = tokenManager.peek(0).get().getType();

        if (nextTokenType == Token.TokenTypes.IF) {
            return If();
        } else if (nextTokenType == Token.TokenTypes.LOOP) {
            return Loop();
        } else if (nextTokenType == Token.TokenTypes.NEWLINE) {
            tokenManager.matchAndRemove(Token.TokenTypes.NEWLINE);
            return null;
        } else {
            Optional<StatementNode> statementOpt = disambiguate();
            if (statementOpt.isPresent()) {

                if (tokenManager.peek(0).isPresent() && tokenManager.peek(0).get().getType() == Token.TokenTypes.NEWLINE) {
                    tokenManager.matchAndRemove(Token.TokenTypes.NEWLINE);
                }
                return statementOpt.get();
            } else {
                throw new SyntaxErrorException("Invalid statement",
                        tokenManager.peek(0).get().getLineNumber(),
                        tokenManager.peek(0).get().getColumnNumber());
            }
        }
    }

    // Implement disambiguate()
    private Optional<StatementNode> disambiguate() throws SyntaxErrorException {
        Optional<Token> nextToken = tokenManager.peek(0);
        if (nextToken.isPresent() && nextToken.get().getType() == Token.TokenTypes.WORD) {

            Optional<Token> secondToken = tokenManager.peek(1);

            if (secondToken.isPresent()) {
                Token.TokenTypes secondTokenType = secondToken.get().getType();

                if (secondTokenType == Token.TokenTypes.ASSIGN || secondTokenType == Token.TokenTypes.COMMA) {

                    List<VariableReferenceNode> variableReferences = parseVariableReferenceList();

                    tokenManager.matchAndRemove(Token.TokenTypes.ASSIGN)
                            .orElseThrow(() -> new SyntaxErrorException("Expected '=' after variable(s)",
                                    tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                                    tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));


                    ExpressionNode expressionNode = Expression();

                    if (expressionNode instanceof MethodCallExpressionNode) {

                        MethodCallStatementNode methodCallStmt = new MethodCallStatementNode();
                        methodCallStmt.returnValues.addAll(variableReferences);
                        methodCallStmt.methodName = ((MethodCallExpressionNode) expressionNode).methodName;
                        methodCallStmt.parameters = ((MethodCallExpressionNode) expressionNode).parameters;
                        methodCallStmt.objectName = ((MethodCallExpressionNode) expressionNode).objectName;
                        return Optional.of(methodCallStmt);
                    } else {
                        if (variableReferences.size() > 1) {
                            throw new SyntaxErrorException("Multiple assignment only allowed with method call expression",
                                    tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                                    tokenManager.peek(0).map(Token::getColumnNumber).orElse(0));
                        }
                        // Create an AssignmentNode
                        AssignmentNode assignmentNode = new AssignmentNode();
                        assignmentNode.target = variableReferences.get(0);
                        assignmentNode.expression = expressionNode;
                        return Optional.of(assignmentNode);
                    }
                } else if (secondTokenType == Token.TokenTypes.LPAREN || secondTokenType == Token.TokenTypes.DOT) {
                    MethodCallExpressionNode methodCallExpr = MethodCallExpression();
                    MethodCallStatementNode methodCallStmt = new MethodCallStatementNode(methodCallExpr);
                    return Optional.of(methodCallStmt);
                } else {
                    Token errorToken = secondToken.get();
                    throw new SyntaxErrorException("Invalid statement",
                            errorToken.getLineNumber(), errorToken.getColumnNumber());
                }
            } else {
                Token errorToken = nextToken.get();
                throw new SyntaxErrorException("Incomplete statement",
                        errorToken.getLineNumber(), errorToken.getColumnNumber());
            }
        } else {
            Token errorToken = tokenManager.peek(0).orElseThrow(() ->
                    new SyntaxErrorException("Unexpected end of input", 0, 0));
            throw new SyntaxErrorException("Invalid statement",
                    errorToken.getLineNumber(), errorToken.getColumnNumber());
        }
    }

    // Parse a list of variable references
    private List<VariableReferenceNode> parseVariableReferenceList() throws SyntaxErrorException {
        List<VariableReferenceNode> variables = new ArrayList<>();

        variables.add(VariableReference());

        while (tokenManager.peek(0).isPresent() && tokenManager.peek(0).get().getType() == Token.TokenTypes.COMMA) {
            tokenManager.matchAndRemove(Token.TokenTypes.COMMA);
            variables.add(VariableReference());
        }

        return variables;
    }

    // Implement VariableReference()
    private VariableReferenceNode VariableReference() throws SyntaxErrorException {
        Token variableToken = tokenManager.matchAndRemove(Token.TokenTypes.WORD)
                .orElseThrow(() -> new SyntaxErrorException("Expected variable name",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        VariableReferenceNode variableReferenceNode = new VariableReferenceNode();
        variableReferenceNode.name = variableToken.getValue();

        return variableReferenceNode;
    }

    // Implement Expression()
    private ExpressionNode Expression() throws SyntaxErrorException {
        ExpressionNode left = Term();

        while (true) {
            Optional<Token> nextTokenOpt = tokenManager.peek(0);
            if (nextTokenOpt.isPresent()) {
                Token nextToken = nextTokenOpt.get();
                if (nextToken.getType() == Token.TokenTypes.PLUS ||
                        nextToken.getType() == Token.TokenTypes.MINUS) {

                    Token operatorToken = tokenManager.matchAndRemove(nextToken.getType()).get();

                    ExpressionNode right = Term();

                    MathOpNode mathOpNode = new MathOpNode();
                    mathOpNode.left = left;
                    mathOpNode.right = right;

                    if (operatorToken.getType() == Token.TokenTypes.PLUS) {
                        mathOpNode.op = MathOpNode.MathOperations.add;
                    } else {
                        mathOpNode.op = MathOpNode.MathOperations.subtract;
                    }

                    left = mathOpNode;
                } else {
                    break;
                }
            } else {
                break;
            }
        }

        return left;
    }

    // Implement Term()
    private ExpressionNode Term() throws SyntaxErrorException {
        ExpressionNode left = Factor();

        while (true) {
            Optional<Token> nextTokenOpt = tokenManager.peek(0);
            if (nextTokenOpt.isPresent()) {
                Token nextToken = nextTokenOpt.get();
                if (nextToken.getType() == Token.TokenTypes.TIMES ||
                        nextToken.getType() == Token.TokenTypes.DIVIDE ||
                        nextToken.getType() == Token.TokenTypes.MODULO) {

                    Token operatorToken = tokenManager.matchAndRemove(nextToken.getType()).get();

                    ExpressionNode right = Factor();

                    MathOpNode mathOpNode = new MathOpNode();
                    mathOpNode.left = left;
                    mathOpNode.right = right;

                    if (operatorToken.getType() == Token.TokenTypes.TIMES) {
                        mathOpNode.op = MathOpNode.MathOperations.multiply;
                    } else if (operatorToken.getType() == Token.TokenTypes.DIVIDE) {
                        mathOpNode.op = MathOpNode.MathOperations.divide;
                    } else if (operatorToken.getType() == Token.TokenTypes.MODULO) {
                        mathOpNode.op = MathOpNode.MathOperations.modulo;
                    }

                    left = mathOpNode;
                } else {
                    break;
                }
            } else {
                break;
            }
        }

        return left;
    }

    // Implement Factor()
    private ExpressionNode Factor() throws SyntaxErrorException {
        Optional<Token> nextTokenOpt = tokenManager.peek(0);
        if (!nextTokenOpt.isPresent()) {
            throw new SyntaxErrorException("Expected expression, but found end of input",
                    0, 0);
        }

        Token nextToken = nextTokenOpt.get();
        switch (nextToken.getType()) {
            case LPAREN:
                tokenManager.matchAndRemove(Token.TokenTypes.LPAREN);
                ExpressionNode expression = Expression();
                tokenManager.matchAndRemove(Token.TokenTypes.RPAREN)
                        .orElseThrow(() -> new SyntaxErrorException("Expected ')'",
                                tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                                tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));
                return expression;

            case MINUS:
                tokenManager.matchAndRemove(Token.TokenTypes.MINUS);
                ExpressionNode operand = Factor();
                NumericLiteralNode zeroNode = new NumericLiteralNode();
                zeroNode.value = 0.0f;
                MathOpNode mathOpNode = new MathOpNode();
                mathOpNode.left = zeroNode;
                mathOpNode.right = operand;
                mathOpNode.op = MathOpNode.MathOperations.subtract;
                return mathOpNode;

            case NOT:
                tokenManager.matchAndRemove(Token.TokenTypes.NOT);
                ExpressionNode notOperand = Factor();
                NotOpNode notOpNode = new NotOpNode();
                notOpNode.left = notOperand;
                return notOpNode;

            case NEW:
                // Handle 'new' expressions
                tokenManager.matchAndRemove(Token.TokenTypes.NEW);
                Token classNameToken = tokenManager.matchAndRemove(Token.TokenTypes.WORD)
                        .orElseThrow(() -> new SyntaxErrorException("Expected class name after 'new'",
                                tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                                tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));
                String className = classNameToken.getValue();

                tokenManager.matchAndRemove(Token.TokenTypes.LPAREN)
                        .orElseThrow(() -> new SyntaxErrorException("Expected '(' after class name",
                                tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                                tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

                List<ExpressionNode> arguments = new ArrayList<>();

                // Check for arguments
                if (tokenManager.peek(0).isPresent() && tokenManager.peek(0).get().getType() != Token.TokenTypes.RPAREN) {
                    arguments.add(Expression());
                    while (tokenManager.peek(0).isPresent() && tokenManager.peek(0).get().getType() == Token.TokenTypes.COMMA) {
                        tokenManager.matchAndRemove(Token.TokenTypes.COMMA);
                        arguments.add(Expression());
                    }
                }

                tokenManager.matchAndRemove(Token.TokenTypes.RPAREN)
                        .orElseThrow(() -> new SyntaxErrorException("Expected ')' after constructor arguments",
                                tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                                tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

                NewNode newNode = new NewNode();
                newNode.className = className;
                newNode.parameters = arguments;
                return newNode;

            case WORD:
                Optional<Token> secondTokenOpt = tokenManager.peek(1);
                if (secondTokenOpt.isPresent()) {
                    Token secondToken = secondTokenOpt.get();
                    if (secondToken.getType() == Token.TokenTypes.LPAREN || secondToken.getType() == Token.TokenTypes.DOT) {
                        return MethodCallExpression();
                    } else {
                        return VariableReference();
                    }
                } else {
                    return VariableReference();
                }

            case NUMBER:
                return NumericLiteral();

            case QUOTEDSTRING:
                return StringLiteral();

            case TRUE:
            case FALSE:
                return BooleanLiteral();

            default:
                throw new SyntaxErrorException("Unexpected token in expression: " + nextToken.getValue(),
                        nextToken.getLineNumber(), nextToken.getColumnNumber());
        }
    }

    // Implement MethodCallExpression()
    private MethodCallExpressionNode MethodCallExpression() throws SyntaxErrorException {
        Token nameToken = tokenManager.matchAndRemove(Token.TokenTypes.WORD)
                .orElseThrow(() -> new SyntaxErrorException("Expected method or object name",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));
        String name = nameToken.getValue();

        Optional<String> objectName = Optional.empty();
        String methodName;

        if (tokenManager.peek(0).isPresent() && tokenManager.peek(0).get().getType() == Token.TokenTypes.DOT) {
            tokenManager.matchAndRemove(Token.TokenTypes.DOT);
            objectName = Optional.of(name);

            Token methodNameToken = tokenManager.matchAndRemove(Token.TokenTypes.WORD)
                    .orElseThrow(() -> new SyntaxErrorException("Expected method name after '.'",
                            tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                            tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));
            methodName = methodNameToken.getValue();
        } else {
            methodName = name;
        }

        tokenManager.matchAndRemove(Token.TokenTypes.LPAREN)
                .orElseThrow(() -> new SyntaxErrorException("Expected '(' after method name",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        List<ExpressionNode> arguments = new ArrayList<>();

        if (tokenManager.peek(0).isPresent() && tokenManager.peek(0).get().getType() != Token.TokenTypes.RPAREN) {
            arguments.add(Expression());
            while (tokenManager.peek(0).isPresent() && tokenManager.peek(0).get().getType() == Token.TokenTypes.COMMA) {
                tokenManager.matchAndRemove(Token.TokenTypes.COMMA);
                arguments.add(Expression());
            }
        }

        tokenManager.matchAndRemove(Token.TokenTypes.RPAREN)
                .orElseThrow(() -> new SyntaxErrorException("Expected ')' after method call arguments",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        MethodCallExpressionNode methodCallExpressionNode = new MethodCallExpressionNode();
        methodCallExpressionNode.methodName = methodName;
        methodCallExpressionNode.parameters = arguments;
        methodCallExpressionNode.objectName = objectName;

        return methodCallExpressionNode;
    }

    // Implement NumericLiteral()
    private NumericLiteralNode NumericLiteral() throws SyntaxErrorException {
        Token numberToken = tokenManager.matchAndRemove(Token.TokenTypes.NUMBER)
                .orElseThrow(() -> new SyntaxErrorException("Expected number literal",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        NumericLiteralNode numericLiteralNode = new NumericLiteralNode();
        numericLiteralNode.value = Float.parseFloat(numberToken.getValue());

        return numericLiteralNode;
    }

    // Implement StringLiteral()
    private StringLiteralNode StringLiteral() throws SyntaxErrorException {
        Token stringToken = tokenManager.matchAndRemove(Token.TokenTypes.QUOTEDSTRING)
                .orElseThrow(() -> new SyntaxErrorException("Expected string literal",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        StringLiteralNode stringLiteralNode = new StringLiteralNode();
        stringLiteralNode.value = stringToken.getValue();

        return stringLiteralNode;
    }

    // BooleanLiteral() method
    private BooleanLiteralNode BooleanLiteral() throws SyntaxErrorException {
        Optional<Token> boolTokenOpt = tokenManager.matchAndRemove(Token.TokenTypes.TRUE);
        if (boolTokenOpt.isPresent()) {
            return new BooleanLiteralNode(true);
        }
        boolTokenOpt = tokenManager.matchAndRemove(Token.TokenTypes.FALSE);
        if (boolTokenOpt.isPresent()) {
            return new BooleanLiteralNode(false);
        }

        Token errorToken = tokenManager.peek(0).orElse(null);
        int lineNumber = errorToken != null ? errorToken.getLineNumber() : 0;
        int columnNumber = errorToken != null ? errorToken.getColumnNumber() : 0;
        throw new SyntaxErrorException("Expected boolean literal", lineNumber, columnNumber);
    }

    // Adjusted BoolExpFactor()
    private ExpressionNode BoolExpFactor() throws SyntaxErrorException {
        ExpressionNode leftExpression = Expression();

        // Array of comparison token types
        Token.TokenTypes[] comparisonTokenTypes = {
                Token.TokenTypes.LESSTHAN,
                Token.TokenTypes.LESSTHANEQUAL,
                Token.TokenTypes.GREATERTHAN,
                Token.TokenTypes.GREATERTHANEQUAL,
                Token.TokenTypes.EQUAL,
                Token.TokenTypes.NOTEQUAL
        };

        Optional<Token> comparisonTokenOpt = Optional.empty();

        for (Token.TokenTypes tokenType : comparisonTokenTypes) {
            Optional<Token> matchedToken = tokenManager.matchAndRemove(tokenType);
            if (matchedToken.isPresent()) {
                comparisonTokenOpt = matchedToken;
                break;
            }
        }

        if (!comparisonTokenOpt.isPresent()) {
            return leftExpression;
        }

        Token comparisonToken = comparisonTokenOpt.get();

        // Map the token to CompareOperations
        CompareNode.CompareOperations compareOperation;
        switch (comparisonToken.getType()) {
            case LESSTHAN:
                compareOperation = CompareNode.CompareOperations.lt;
                break;
            case LESSTHANEQUAL:
                compareOperation = CompareNode.CompareOperations.le;
                break;
            case GREATERTHAN:
                compareOperation = CompareNode.CompareOperations.gt;
                break;
            case GREATERTHANEQUAL:
                compareOperation = CompareNode.CompareOperations.ge;
                break;
            case EQUAL:
                compareOperation = CompareNode.CompareOperations.eq;
                break;
            case NOTEQUAL:
                compareOperation = CompareNode.CompareOperations.ne;
                break;
            default:
                throw new SyntaxErrorException("Unknown comparison operator",
                        comparisonToken.getLineNumber(),
                        comparisonToken.getColumnNumber());
        }

        ExpressionNode rightExpression = Expression();

        CompareNode compareNode = new CompareNode();
        compareNode.left = leftExpression;
        compareNode.right = rightExpression;
        compareNode.op = compareOperation;

        return compareNode;
    }

    private ExpressionNode BoolExpTerm() throws SyntaxErrorException {
        ExpressionNode left = BoolExpFactor();

        while (true) {
            Optional<Token> nextTokenOpt = tokenManager.peek(0);
            if (nextTokenOpt.isPresent() && nextTokenOpt.get().getType() == Token.TokenTypes.AND) {
                tokenManager.matchAndRemove(Token.TokenTypes.AND);

                ExpressionNode right = BoolExpFactor();

                BooleanOpNode booleanOpNode = new BooleanOpNode();
                booleanOpNode.left = left;
                booleanOpNode.right = right;
                booleanOpNode.op = BooleanOpNode.BooleanOperations.and;

                left = booleanOpNode;
            } else {
                break;
            }
        }

        return left;
    }

    private ExpressionNode BoolExpression() throws SyntaxErrorException {
        ExpressionNode left = BoolExpTerm();

        while (true) {
            Optional<Token> nextTokenOpt = tokenManager.peek(0);
            if (nextTokenOpt.isPresent() && nextTokenOpt.get().getType() == Token.TokenTypes.OR) {
                tokenManager.matchAndRemove(Token.TokenTypes.OR);

                ExpressionNode right = BoolExpTerm();

                BooleanOpNode booleanOpNode = new BooleanOpNode();
                booleanOpNode.left = left;
                booleanOpNode.right = right;
                booleanOpNode.op = BooleanOpNode.BooleanOperations.or;

                left = booleanOpNode;
            } else {
                break;
            }
        }

        return left;
    }

    private IfNode If() throws SyntaxErrorException {
        tokenManager.matchAndRemove(Token.TokenTypes.IF)
                .orElseThrow(() -> new SyntaxErrorException("Expected 'if' keyword",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        ExpressionNode condition = null;
        if (tokenManager.peek(0).isPresent() && tokenManager.peek(0).get().getType() != Token.TokenTypes.NEWLINE) {
            condition = BoolExpression();
        } else {
            condition = null;
        }

        RequireNewLine();

        tokenManager.matchAndRemove(Token.TokenTypes.INDENT)
                .orElseThrow(() -> new SyntaxErrorException("Expected INDENT after 'if' statement",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        List<StatementNode> ifStatements = Statements();

        tokenManager.matchAndRemove(Token.TokenTypes.DEDENT)
                .orElseThrow(() -> new SyntaxErrorException("Expected DEDENT after 'if' block",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        IfNode ifNode = new IfNode();
        ifNode.condition = condition;
        ifNode.statements = ifStatements;
        ifNode.elseStatement = Optional.empty();

        if (tokenManager.peek(0).isPresent() && tokenManager.peek(0).get().getType() == Token.TokenTypes.ELSE) {
            tokenManager.matchAndRemove(Token.TokenTypes.ELSE);
            RequireNewLine();

            tokenManager.matchAndRemove(Token.TokenTypes.INDENT)
                    .orElseThrow(() -> new SyntaxErrorException("Expected INDENT after 'else' statement",
                            tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                            tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

            List<StatementNode> elseStatements = Statements();

            tokenManager.matchAndRemove(Token.TokenTypes.DEDENT)
                    .orElseThrow(() -> new SyntaxErrorException("Expected DEDENT after 'else' block",
                            tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                            tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

            ElseNode elseNode = new ElseNode();
            elseNode.statements = elseStatements;

            ifNode.elseStatement = Optional.of(elseNode);
        }

        return ifNode;
    }

    // Loop() method
    private LoopNode Loop() throws SyntaxErrorException {
        tokenManager.matchAndRemove(Token.TokenTypes.LOOP)
                .orElseThrow(() -> new SyntaxErrorException("Expected 'loop' keyword",
                        tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                        tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));

        ExpressionNode condition = null;
        VariableReferenceNode assignmentVar = null;

        Optional<Token> nextTokenOpt = tokenManager.peek(0);
        if (nextTokenOpt.isPresent() && nextTokenOpt.get().getType() != Token.TokenTypes.NEWLINE) {
            if (nextTokenOpt.get().getType() == Token.TokenTypes.WORD) {
                Optional<Token> nextNextTokenOpt = tokenManager.peek(1);
                if (nextNextTokenOpt.isPresent() && nextNextTokenOpt.get().getType() == Token.TokenTypes.ASSIGN) {
                    assignmentVar = VariableReference();
                    tokenManager.matchAndRemove(Token.TokenTypes.ASSIGN);
                    condition = BoolExpression();
                } else {
                    condition = BoolExpression();
                }
            } else {
                condition = BoolExpression();
            }
        } else {
            condition = null;
        }

        RequireNewLine();

        List<StatementNode> statements = new ArrayList<>();
        if (tokenManager.peek(0).isPresent() && tokenManager.peek(0).get().getType() == Token.TokenTypes.INDENT) {
            tokenManager.matchAndRemove(Token.TokenTypes.INDENT);
            statements = Statements();
            tokenManager.matchAndRemove(Token.TokenTypes.DEDENT)
                    .orElseThrow(() -> new SyntaxErrorException("Expected DEDENT after 'loop' block",
                            tokenManager.peek(0).map(Token::getLineNumber).orElse(0),
                            tokenManager.peek(0).map(Token::getColumnNumber).orElse(0)));
        }

        LoopNode loopNode = new LoopNode();
        loopNode.expression = condition;
        loopNode.statements = statements;
        loopNode.assignment = Optional.ofNullable(assignmentVar);
        return loopNode;
    }

    // Helper method to parse method or constructor bodies
    private void parseMethodOrConstructorBody(List<VariableDeclarationNode> locals, List<StatementNode> statements) throws SyntaxErrorException {
        while (true) {
            if (tokenManager.peek(0).isPresent()) {
                Token nextToken = tokenManager.peek(0).get();
                System.out.println("Parsing Token: " + nextToken.getType() + " at Line: " + nextToken.getLineNumber() + ", Column: " + nextToken.getColumnNumber());

                if (nextToken.getType() == Token.TokenTypes.DEDENT) {
                    break;
                }

                if (nextToken.getType() == Token.TokenTypes.NEWLINE) {
                    tokenManager.matchAndRemove(Token.TokenTypes.NEWLINE);
                } else if (nextToken.getType() == Token.TokenTypes.WORD) {
                    Optional<Token> secondToken = tokenManager.peek(1);
                    if (secondToken.isPresent() && secondToken.get().getType() == Token.TokenTypes.WORD) {
                        VariableDeclarationNode variable = VariableDeclaration();
                        locals.add(variable);
                        System.out.println("Parsed Variable Declaration: " + variable.name);

                        if (tokenManager.peek(0).isPresent() && tokenManager.peek(0).get().getType() == Token.TokenTypes.NEWLINE) {
                            tokenManager.matchAndRemove(Token.TokenTypes.NEWLINE);
                        }
                    } else {
                        StatementNode statement = Statement();
                        if (statement != null) {
                            statements.add(statement);
                            System.out.println("Parsed Statement: " + statement.toString());
                        }
                    }
                } else if (nextToken.getType() == Token.TokenTypes.IF ||
                        nextToken.getType() == Token.TokenTypes.LOOP) {
                    StatementNode statement = Statement();
                    if (statement != null) {
                        statements.add(statement);
                        System.out.println("Parsed Control Statement: " + statement.toString());
                    }
                } else {
                    throw new SyntaxErrorException("Unexpected token in method body",
                            nextToken.getLineNumber(),
                            nextToken.getColumnNumber());
                }
            } else {
                break;
            }
        }
    }



}
