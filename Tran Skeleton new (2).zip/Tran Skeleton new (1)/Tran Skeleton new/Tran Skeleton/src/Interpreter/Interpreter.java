package Interpreter;

import AST.*;
import Interpreter.InterpreterDataType.*;

import java.util.*;

public class Interpreter {
    private TranNode top;

    /**
     * Constructor - get the interpreter ready to run. Set members from parameters and "prepare" the class.
     * <p>
     * Store the TranNode.
     * Add any built-in methods to the AST.
     *
     * @param top - the head of the AST
     */
    public Interpreter(TranNode top) {
        this.top = top;

        // Add built-in 'console' class with 'write' method to the AST
        addConsoleClass();
    }

    /**
     * Adds the 'console' class with the 'write' method to the AST.
     * This method does not modify any existing classes.
     */
    private void addConsoleClass() {
        // Check if 'console' class already exists
        Optional<ClassNode> consoleClassOpt = getClassByName("console");
        ClassNode consoleClass;
        if (consoleClassOpt.isPresent()) {
            consoleClass = consoleClassOpt.get();
        } else {
            // Create 'console' class and add it to the AST
            consoleClass = new ClassNode();
            consoleClass.name = "console";
            consoleClass.methods = new LinkedList<>();
            consoleClass.members = new LinkedList<>();
            consoleClass.constructors = new LinkedList<>();
            top.Classes.add(consoleClass);
        }

        // Add 'write' method to 'console' class if it doesn't already exist
        boolean writeMethodExists = consoleClass.methods.stream()
                .anyMatch(method -> method.name.equals("write"));
        if (!writeMethodExists) {
            // Create an instance of ConsoleWrite and add it to methods
            ConsoleWrite writeMethod = new ConsoleWrite();
            writeMethod.name = "write";
            writeMethod.isShared = true;
            writeMethod.parameters = null; // Since it's variadic and parameters are not predefined
            writeMethod.returns = null;    // No return values

            // Add the method to the class's methods list
            consoleClass.methods.add(writeMethod);
        }
    }

    /**
     * This is the public interface to the interpreter. After parsing, we will create an interpreter and call start to
     * start interpreting the code.
     * <p>
     * Search the classes in Tran for a method that is "isShared", named "start", that is not private and has no parameters.
     * Call "interpretMethodCall" on that method, then return.
     * Throw an exception if no such method exists.
     */
    public void start() {
        // Look for a shared method 'start' with no parameters
        for (ClassNode classNode : top.Classes) {
            for (MethodDeclarationNode method : classNode.methods) {
                if (method.isShared && !method.isPrivate && method.name.equals("start") &&
                        (method.parameters == null || method.parameters.isEmpty())) {

                    // Run the method
                    interpretMethodCall(Optional.empty(), method, List.of());
                    return;
                }
            }
        }
        throw new RuntimeException("No suitable 'start' method found.");
    }

    //              Running Methods

    /**
     * Find the method (local to this class, shared, or a method on another class).
     * Evaluate the parameters to have a list of values.
     * Use interpretMethodCall() to actually run the method.
     * <p>
     * Call getParameters() to get the parameter value list.
     * Find the method. This is tricky - there are several cases:
     * - someLocalMethod() - has NO object name. Look in "object".
     * - console.write() - the objectName is a CLASS and the method is shared.
     * - bestStudent.getGPA() - the objectName is a local or a member.
     * <p>
     * Once you find the method, call interpretMethodCall() on it. Return the list that it returns.
     * Throw an exception if we can't find a match.
     *
     * @param object - the object we are inside right now (might be empty)
     * @param locals - the current local variables
     * @param mc     - the method call
     * @return - the return values
     */
    private List<InterpreterDataType> findMethodForMethodCallAndRunIt(
            Optional<ObjectIDT> object,
            HashMap<String, InterpreterDataType> locals,
            MethodCallStatementNode mc) {

        List<InterpreterDataType> parameterValues = getParameters(object, locals, mc);

        // Case 1: Method call without an object name (local method)
        if (mc.objectName.isEmpty()) {
            if (object.isPresent()) {
                // Look for method in current object
                MethodDeclarationNode method = getMethodFromObject(object.get(), mc, parameterValues);
                return interpretMethodCall(object, method, parameterValues);
            } else {
                // Look for shared methods in all classes
                for (ClassNode classNode : top.Classes) {
                    for (MethodDeclarationNode method : classNode.methods) {
                        if (method.isShared && !method.isPrivate && method.name.equals(mc.methodName)) {
                            if (doesMatch(method, mc, parameterValues)) {
                                return interpretMethodCall(Optional.empty(), method, parameterValues);
                            }
                        }
                    }
                }
                throw new RuntimeException("No object context for method call: " + mc.methodName);
            }
        }

        // mc.objectName is present
        String objectName = mc.objectName.get();

        // First, check if objectName is a class name (for shared methods)
        Optional<ClassNode> classNodeOpt = getClassByName(objectName);
        if (classNodeOpt.isPresent()) {
            ClassNode classNode = classNodeOpt.get();
            // Look for a shared method in the class
            for (MethodDeclarationNode method : classNode.methods) {
                if (method.isShared && method.name.equals(mc.methodName)) {
                    if (doesMatch(method, mc, parameterValues)) {
                        return interpretMethodCall(Optional.empty(), method, parameterValues);
                    }
                }
            }
        }

        // Otherwise, objectName is a variable (local or member)
        InterpreterDataType varIDT = findVariable(objectName, locals, object);
        if (varIDT instanceof ReferenceIDT refIDT) {
            if (refIDT.refersTo.isPresent()) {
                varIDT = refIDT.refersTo.get();
            } else {
                throw new RuntimeException("Variable '" + objectName + "' is null.");
            }
        }

        if (varIDT instanceof ObjectIDT objIDT) {
            MethodDeclarationNode method = getMethodFromObject(objIDT, mc, parameterValues);
            return interpretMethodCall(Optional.of(objIDT), method, parameterValues);
        }

        throw new RuntimeException("Unable to resolve method call: " + mc.methodName);
    }

    /**
     * Run a "prepared" method (found, parameters evaluated).
     * This is split from findMethodForMethodCallAndRunIt() because there are a few cases where we don't need to do the finding:
     * in start() and dealing with loops with iterator objects, for example.
     * <p>
     * Check to see if "m" is a built-in. If so, call Execute() on it and return.
     * Make local variables, per "m".
     * If the number of passed-in values doesn't match m's "expectations", throw.
     * Add the parameters by name to locals.
     * Call interpretStatementBlock.
     * Build the return list - find the names from "m", then get the values for those names and add them to the list.
     *
     * @param object - The object this method is being called on (might be empty for shared)
     * @param m      - Which method is being called
     * @param values - The values to be passed in
     * @return the returned values from the method
     */
    private List<InterpreterDataType> interpretMethodCall(
            Optional<ObjectIDT> object,
            MethodDeclarationNode m,
            List<InterpreterDataType> values) {

        // Check if the method is a built-in method
        if (m instanceof BuiltInMethodDeclarationNode) {
            return ((BuiltInMethodDeclarationNode) m).Execute(values);
        }

        // Prepare local variables
        HashMap<String, InterpreterDataType> locals = new HashMap<>();

        // Check parameter count
        if (m.parameters != null) {
            if (m.parameters.size() != values.size()) {
                throw new RuntimeException("Parameter count mismatch in method call: " + m.name);
            }
        } else {
            // If parameters are null, we expect no parameters unless it's a built-in variadic method
            if (!values.isEmpty()) {
                throw new RuntimeException("Method '" + m.name + "' does not take any parameters.");
            }
        }

        // Add parameters to locals
        if (m.parameters != null) {
            for (int i = 0; i < m.parameters.size(); i++) {
                VariableDeclarationNode param = m.parameters.get(i);
                InterpreterDataType value = values.get(i);
                locals.put(param.name, value);
            }
        }

        // Add local variable declarations
        if (m.locals != null) {
            for (VariableDeclarationNode localVar : m.locals) {
                InterpreterDataType localValue = instantiate(localVar.type);
                locals.put(localVar.name, localValue);
            }
        }

        // Interpret method body
        interpretStatementBlock(object, m.statements, locals);

        // Prepare return values
        List<InterpreterDataType> returnValues = new LinkedList<>();
        if (m.returns != null) {
            for (VariableDeclarationNode returnVar : m.returns) {
                InterpreterDataType returnValue = locals.get(returnVar.name);
                if (returnValue == null) {
                    throw new RuntimeException("Return value '" + returnVar.name + "' not set in method: " + m.name);
                }
                returnValues.add(returnValue);
            }
        }

        return returnValues;
    }

    //              Running Constructors

    /**
     * This is a special case of the code for methods. Just different enough to make it worthwhile to split it out.
     * <p>
     * Call getParameters() to populate a list of IDTs.
     * Call getClassByName() to find the class for the constructor.
     * If we didn't find the class, throw an exception.
     * Find a constructor that is a good match - use doesConstructorMatch().
     * Call interpretConstructorCall() on the good match.
     *
     * @param callerObj - the object that we are inside when we called the constructor
     * @param locals    - the current local variables (used to fill parameters)
     * @param mc        - the method call for this construction
     * @param newOne    - the object that we just created that we are calling the constructor for
     */
    private void findConstructorAndRunIt(
            Optional<ObjectIDT> callerObj,
            HashMap<String, InterpreterDataType> locals,
            MethodCallStatementNode mc,
            ObjectIDT newOne) {

        List<InterpreterDataType> parameterValues = getParameters(callerObj, locals, mc);

        // Get class by name
        ClassNode classNode = newOne.astNode;

        // Find a constructor that is a good match
        for (ConstructorNode constructor : classNode.constructors) {
            if (doesConstructorMatch(constructor, mc, parameterValues)) {
                interpretConstructorCall(newOne, constructor, parameterValues);
                return;
            }
        }

        // If no constructor is found, assume an implicit default constructor
        if (classNode.constructors.isEmpty() && parameterValues.isEmpty()) {
            ConstructorNode defaultConstructor = new ConstructorNode();
            defaultConstructor.parameters = new LinkedList<>();
            defaultConstructor.locals = new LinkedList<>();
            defaultConstructor.statements = new LinkedList<>();
            interpretConstructorCall(newOne, defaultConstructor, parameterValues);
            return;
        }

        throw new RuntimeException("No matching constructor found for class: " + classNode.name);
    }

    /**
     * Similar to interpretMethodCall, but "just different enough" - for example, constructors don't return anything.
     * <p>
     * Creates local variables (as defined by the ConstructorNode), calls instantiate() to do the creation.
     * Checks to ensure that the right number of parameters were passed in; if not, throw.
     * Adds the parameters (with the names from the ConstructorNode) to the locals.
     * Calls interpretStatementBlock.
     *
     * @param object - the object that we allocated
     * @param c      - which constructor is being called
     * @param values - the parameter values being passed to the constructor
     */
    private void interpretConstructorCall(
            ObjectIDT object,
            ConstructorNode c,
            List<InterpreterDataType> values) {

        // Prepare local variables
        HashMap<String, InterpreterDataType> locals = new HashMap<>();

        // Check parameter counts
        if (c.parameters != null && c.parameters.size() != values.size()) {
            throw new RuntimeException("Parameter count mismatch in constructor call.");
        }

        // Add parameters to locals
        if (c.parameters != null) {
            for (int i = 0; i < c.parameters.size(); i++) {
                VariableDeclarationNode param = c.parameters.get(i);
                InterpreterDataType value = values.get(i);
                locals.put(param.name, value);
            }
        }

        // Instantiate members
        for (MemberNode member : object.astNode.members) {
            InterpreterDataType memberValue = instantiate(member.declaration.type);
            object.members.put(member.declaration.name, memberValue);
        }

        // Interpret constructor body
        interpretStatementBlock(Optional.of(object), c.statements, locals);
    }

    //              Running Instructions

    /**
     * Given a block (which could be from a method or an "if" or "loop" block), run each statement.
     * Blocks, by definition, execute every statement, so iterating over the statements makes sense.
     * <p>
     * For each statement in statements:
     * - For AssignmentNode, findVariable() to get the target. Evaluate() the expression. Call Assign() on the target with the result of Evaluate().
     * - For MethodCallStatementNode, call findMethodForMethodCallAndRunIt(). Loop over the returned values and copy them into our local variables.
     * - For LoopNode - only handle boolean loops since 'isIterator' is not available.
     * - For If - Evaluate() the condition. If true, interpretStatementBlock() on the if's statements. If not AND there is an else, interpretStatementBlock on the else body.
     *
     * @param object     - the object that this statement block belongs to (used to get member variables and any members without an object)
     * @param statements - the statements to run
     * @param locals     - the local variables
     */
    private void interpretStatementBlock(
            Optional<ObjectIDT> object,
            List<StatementNode> statements,
            HashMap<String, InterpreterDataType> locals) {

        for (StatementNode statement : statements) {
            if (statement instanceof AssignmentNode assignNode) {
                InterpreterDataType target = findVariable(assignNode.target.name, locals, object);
                InterpreterDataType value = evaluate(locals, object, assignNode.expression);
                target.Assign(value);
            } else if (statement instanceof MethodCallStatementNode mc) {
                List<InterpreterDataType> results = findMethodForMethodCallAndRunIt(object, locals, mc);
                // Handle return values if any
                if (!mc.returnValues.isEmpty()) {
                    if (mc.returnValues.size() != results.size()) {
                        throw new RuntimeException("Return value count mismatch in method call: " + mc.methodName);
                    }
                    for (int i = 0; i < mc.returnValues.size(); i++) {
                        VariableReferenceNode varRef = mc.returnValues.get(i);
                        InterpreterDataType target = findVariable(varRef.name, locals, object);
                        target.Assign(results.get(i));
                    }
                }
            } else if (statement instanceof IfNode ifNode) {
                InterpreterDataType conditionValue = evaluate(locals, object, ifNode.condition);
                if (conditionValue instanceof BooleanIDT boolValue) {
                    if (boolValue.Value) {
                        interpretStatementBlock(object, ifNode.statements, locals);
                    } else if (ifNode.elseStatement.isPresent()) {
                        ElseNode elseNode = ifNode.elseStatement.get();
                        interpretStatementBlock(object, elseNode.statements, locals);
                    }
                } else {
                    throw new RuntimeException("Condition in if statement is not boolean.");
                }
            } else if (statement instanceof LoopNode loopNode) {
                // Handle boolean condition loops
                if (loopNode.assignment.isPresent()) {
                    VariableReferenceNode assignVar = loopNode.assignment.get();
                    InterpreterDataType assignVarIDT = findVariable(assignVar.name, locals, object);
                    while (true) {
                        InterpreterDataType conditionValue = evaluate(locals, object, loopNode.expression);
                        if (conditionValue instanceof BooleanIDT boolValue) {
                            assignVarIDT.Assign(boolValue);
                            if (boolValue.Value) {
                                interpretStatementBlock(object, loopNode.statements, locals);
                            } else {
                                break;
                            }
                        } else {
                            throw new RuntimeException("Loop condition is not boolean.");
                        }
                    }
                } else {
                    while (true) {
                        InterpreterDataType conditionValue = evaluate(locals, object, loopNode.expression);
                        if (conditionValue instanceof BooleanIDT boolValue) {
                            if (boolValue.Value) {
                                interpretStatementBlock(object, loopNode.statements, locals);
                            } else {
                                break;
                            }
                        } else {
                            throw new RuntimeException("Loop condition is not boolean.");
                        }
                    }
                }
            } else {
                throw new RuntimeException("Unknown statement type: " + statement.getClass());
            }
        }
    }

    /**
     * evaluate() processes everything that is an expression - math, variables, boolean expressions.
     * There is a good bit of recursion in here, since math and comparisons have left and right sides that need to be evaluated.
     * <p>
     * For each possible ExpressionNode, do the work to resolve it:
     * - BooleanLiteralNode - create a new BooleanIDT with the same value.
     * - Same for all of the basic data types.
     * - BooleanOpNode - Evaluate() left and right, then perform either and/or on the results.
     * - CompareNode - Evaluate() both sides. Do good comparison for each data type.
     * - MathOpNode - Evaluate() both sides. If they are both numbers, do the math using the built-in operators. Also handle String + String as concatenation (like Java).
     * - MethodCallExpressionNode - call findMethodForMethodCallAndRunIt() and return the first value.
     * - VariableReferenceNode - call findVariable().
     *
     * @param locals     the local variables
     * @param object     - the current object we are running
     * @param expression - some expression to evaluate
     * @return a value
     */
    private InterpreterDataType evaluate(
            HashMap<String, InterpreterDataType> locals,
            Optional<ObjectIDT> object,
            ExpressionNode expression) {

        if (expression instanceof NumericLiteralNode numNode) {
            return new NumberIDT(numNode.value);
        } else if (expression instanceof StringLiteralNode strNode) {
            return new StringIDT(strNode.value);
        } else if (expression instanceof BooleanLiteralNode boolNode) {
            return new BooleanIDT(boolNode.value);
        } else if (expression instanceof VariableReferenceNode varNode) {
            InterpreterDataType variable = findVariable(varNode.name, locals, object);
            if (variable instanceof ReferenceIDT refIDT) {
                if (refIDT.refersTo.isPresent()) {
                    return refIDT.refersTo.get();
                } else {
                    throw new RuntimeException("Variable '" + varNode.name + "' is null.");
                }
            } else {
                return variable;
            }
        } else if (expression instanceof MathOpNode mathNode) {
            InterpreterDataType left = evaluate(locals, object, mathNode.left);
            InterpreterDataType right = evaluate(locals, object, mathNode.right);

            if (left instanceof NumberIDT leftNum && right instanceof NumberIDT rightNum) {
                float result;
                switch (mathNode.op) {
                    case add -> result = leftNum.Value + rightNum.Value;
                    case subtract -> result = leftNum.Value - rightNum.Value;
                    case multiply -> result = leftNum.Value * rightNum.Value;
                    case divide -> result = leftNum.Value / rightNum.Value;
                    case modulo -> result = leftNum.Value % rightNum.Value;
                    default -> throw new RuntimeException("Unknown math operation: " + mathNode.op);
                }
                return new NumberIDT(result);
            } else if (left instanceof StringIDT leftStr && right instanceof StringIDT rightStr && mathNode.op == MathOpNode.MathOperations.add) {
                // Handle string concatenation
                return new StringIDT(leftStr.Value + rightStr.Value);
            } else {
                throw new RuntimeException("Invalid operands for math operation: " + left.getClass() + " and " + right.getClass());
            }
        } else if (expression instanceof BooleanOpNode boolNode) {
            InterpreterDataType left = evaluate(locals, object, boolNode.left);
            InterpreterDataType right = evaluate(locals, object, boolNode.right);

            if (left instanceof BooleanIDT leftBool && right instanceof BooleanIDT rightBool) {
                boolean result;
                switch (boolNode.op) {
                    case and -> result = leftBool.Value && rightBool.Value;
                    case or -> result = leftBool.Value || rightBool.Value;
                    default -> throw new RuntimeException("Unknown boolean operation: " + boolNode.op);
                }
                return new BooleanIDT(result);
            } else {
                throw new RuntimeException("Invalid operands for boolean operation: " + left.getClass() + " and " + right.getClass());
            }
        } else if (expression instanceof CompareNode compareNode) {
            InterpreterDataType left = evaluate(locals, object, compareNode.left);
            InterpreterDataType right = evaluate(locals, object, compareNode.right);

            boolean result;
            if (left instanceof NumberIDT leftNum && right instanceof NumberIDT rightNum) {
                switch (compareNode.op) {
                    case lt -> result = leftNum.Value < rightNum.Value;
                    case le -> result = leftNum.Value <= rightNum.Value;
                    case gt -> result = leftNum.Value > rightNum.Value;
                    case ge -> result = leftNum.Value >= rightNum.Value;
                    case eq -> result = leftNum.Value == rightNum.Value;
                    case ne -> result = leftNum.Value != rightNum.Value;
                    default -> throw new RuntimeException("Unknown compare operation: " + compareNode.op);
                }
            } else if (left instanceof StringIDT leftStr && right instanceof StringIDT rightStr) {
                switch (compareNode.op) {
                    case eq -> result = leftStr.Value.equals(rightStr.Value);
                    case ne -> result = !leftStr.Value.equals(rightStr.Value);
                    default -> throw new RuntimeException("Invalid compare operation for strings: " + compareNode.op);
                }
            } else {
                throw new RuntimeException("Invalid operands for comparison: " + left.getClass() + " and " + right.getClass());
            }
            return new BooleanIDT(result);
        } else if (expression instanceof NotOpNode notNode) {
            InterpreterDataType operand = evaluate(locals, object, notNode.left);
            if (operand instanceof BooleanIDT boolOperand) {
                return new BooleanIDT(!boolOperand.Value);
            } else {
                throw new RuntimeException("Invalid operand for NOT operation: " + operand.getClass());
            }
        } else if (expression instanceof MethodCallExpressionNode mcNode) {
            MethodCallStatementNode mcStatement = new MethodCallStatementNode(mcNode);
            List<InterpreterDataType> results = findMethodForMethodCallAndRunIt(object, locals, mcStatement);
            if (results.isEmpty()) {
                return null; // Or return a NullIDT if you have one
            } else {
                return results.get(0); // Return the first value
            }
        } else if (expression instanceof NewNode newNode) {
            // Instantiate a new object
            Optional<ClassNode> classNodeOpt = getClassByName(newNode.className);
            if (classNodeOpt.isEmpty()) {
                throw new RuntimeException("Class not found: " + newNode.className);
            }
            ClassNode classNode = classNodeOpt.get();
            ObjectIDT newObject = new ObjectIDT(classNode);

            // Prepare MethodCallStatementNode for constructor
            MethodCallStatementNode mc = new MethodCallStatementNode();
            mc.methodName = newNode.className;
            mc.parameters = newNode.parameters;
            findConstructorAndRunIt(object, locals, mc, newObject);
            return newObject;
        }

        throw new RuntimeException("Unsupported expression type: " + expression.getClass());
    }

    //              Utility Methods

    /**
     * Used when trying to find a match to a method call. Given a method declaration, does it match this method call?
     * We double-check with the parameters, too, although in theory JUST checking the declaration to the call should be enough.
     * <p>
     * Match names, parameter counts (both declared count vs method call and declared count vs value list), return counts.
     * If all of those match, consider the types (use typeMatchToIDT).
     * If everything is OK, return true; else return false.
     *
     * @param m          - the method declaration we are considering
     * @param mc         - the method call we are trying to match
     * @param parameters - the parameter values for this method call
     * @return does this method match the method call?
     */
    private boolean doesMatch(
            MethodDeclarationNode m,
            MethodCallStatementNode mc,
            List<InterpreterDataType> parameters) {

        if (!m.name.equals(mc.methodName)) {
            return false;
        }

        // Special handling for 'console.write' (variadic built-in method)
        if (m instanceof BuiltInMethodDeclarationNode && m.name.equals("write")) {
            return true; // Skip parameter validation for 'console.write'
        }

        if (m.parameters == null || mc.parameters == null) {
            // If one of them is null, they must both be empty
            if ((m.parameters == null || m.parameters.isEmpty()) && (mc.parameters == null || mc.parameters.isEmpty())) {
                return true;
            } else {
                return false;
            }
        }

        if (m.parameters.size() != mc.parameters.size()) {
            return false;
        }

        // Type checking can be added here
        for (int i = 0; i < m.parameters.size(); i++) {
            VariableDeclarationNode param = m.parameters.get(i);
            InterpreterDataType arg = parameters.get(i);
            if (!typeMatchToIDT(param.type, arg)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Very similar to doesMatch() except simpler - there are no return values, the name will always match.
     *
     * @param c          - a particular constructor
     * @param mc         - the method call
     * @param parameters - the parameter values
     * @return does this constructor match the method call?
     */
    private boolean doesConstructorMatch(
            ConstructorNode c,
            MethodCallStatementNode mc,
            List<InterpreterDataType> parameters) {

        if ((c.parameters == null && !parameters.isEmpty()) || (c.parameters != null && c.parameters.size() != parameters.size())) {
            return false;
        }

        // Type checking
        if (c.parameters != null) {
            for (int i = 0; i < c.parameters.size(); i++) {
                VariableDeclarationNode param = c.parameters.get(i);
                InterpreterDataType arg = parameters.get(i);
                if (!typeMatchToIDT(param.type, arg)) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Used when we call a method to get the list of values for the parameters.
     * <p>
     * For each parameter in the method call, call evaluate() on the parameter to get an IDT and add it to a list.
     *
     * @param object - the current object
     * @param locals - the local variables
     * @param mc     - a method call
     * @return the list of method values
     */
    private List<InterpreterDataType> getParameters(
            Optional<ObjectIDT> object,
            HashMap<String, InterpreterDataType> locals,
            MethodCallStatementNode mc) {

        List<InterpreterDataType> parameters = new LinkedList<>();
        for (ExpressionNode expr : mc.parameters) {
            InterpreterDataType value = evaluate(locals, object, expr);
            parameters.add(value);
        }
        return parameters;
    }

    /**
     * Used when we have an IDT and we want to see if it matches a type definition.
     * Commonly, when someone is making a function call - do the parameter values match the method declaration?
     * <p>
     * If the IDT is a simple type (boolean, number, etc.) - does the string type match the name of that IDT ("boolean", etc.)?
     * If the IDT is an object, check to see if the name matches OR the class has an interface that matches.
     * If the IDT is a reference, check the inner (referred to) type.
     *
     * @param type the name of a data type (parameter to a method)
     * @param idt  the IDT someone is trying to pass to this method
     * @return is this OK?
     */
    private boolean typeMatchToIDT(String type, InterpreterDataType idt) {
        if (type.equals("boolean") && idt instanceof BooleanIDT) {
            return true;
        } else if (type.equals("number") && idt instanceof NumberIDT) {
            return true;
        } else if (type.equals("string") && idt instanceof StringIDT) {
            return true;
        } else if (type.equals("character") && idt instanceof CharIDT) {
            return true;
        } else if (idt instanceof ObjectIDT obj) {
            if (obj.astNode.name.equals(type)) {
                return true;
            }
            // Check interfaces
            for (String interfaceName : obj.astNode.interfaces) {
                if (interfaceName.equals(type)) {
                    return true;
                }
            }
        } else if (idt instanceof ReferenceIDT refIDT) {
            if (refIDT.refersTo.isPresent()) {
                return typeMatchToIDT(type, refIDT.refersTo.get());
            }
        }
        return false;
    }

    /**
     * Find a method in an object that is the right match for a method call (same name, parameters match, etc.).
     * Uses doesMatch() to do most of the work.
     * <p>
     * Given a method call, we want to loop over the methods for that class, looking for a method that matches or throw.
     *
     * @param object     - an object that we want to find a method on
     * @param mc         - the method call
     * @param parameters - the parameter value list
     * @return a method or throws an exception
     */
    private MethodDeclarationNode getMethodFromObject(
            ObjectIDT object,
            MethodCallStatementNode mc,
            List<InterpreterDataType> parameters) {

        ClassNode classNode = object.astNode;
        for (MethodDeclarationNode method : classNode.methods) {
            if (method.name.equals(mc.methodName)) {
                if (doesMatch(method, mc, parameters)) {
                    return method;
                }
            }
        }
        throw new RuntimeException("Method not found: " + mc.methodName + " in class " + classNode.name);
    }

    /**
     * Find a class, given the name. Just loops over the TranNode's classes member, matching by name.
     * <p>
     * Loop over each class in the top node, comparing names to find a match.
     *
     * @param name Name of the class to find
     * @return either a class node or empty if that class doesn't exist
     */
    private Optional<ClassNode> getClassByName(String name) {
        for (ClassNode classNode : top.Classes) {
            if (classNode.name.equals(name)) {
                return Optional.of(classNode);
            }
        }
        return Optional.empty();
    }

    /**
     * Given an execution environment (the current object, the current local variables), find a variable by name.
     *
     * @param name   - the variable that we are looking for
     * @param locals - the current method's local variables
     * @param object - the current object (so we can find members)
     * @return the IDT that we are looking for or throw an exception
     */
    private InterpreterDataType findVariable(
            String name,
            HashMap<String, InterpreterDataType> locals,
            Optional<ObjectIDT> object) {

        // Check locals
        if (locals.containsKey(name)) {
            return locals.get(name);
        }

        // Check object members
        if (object.isPresent()) {
            ObjectIDT obj = object.get();
            if (obj.members.containsKey(name)) {
                return obj.members.get(name);
            }
        }

        throw new RuntimeException("Variable not found: " + name);
    }

    /**
     * Given a string (the type name), make an IDT for it.
     *
     * @param type The name of the type (string, number, boolean, character). Defaults to ReferenceIDT if not one of those.
     * @return an IDT with default values (0 for number, "" for string, false for boolean, ' ' for character)
     */
    private InterpreterDataType instantiate(String type) {
        switch (type) {
            case "boolean":
                return new BooleanIDT(false);
            case "number":
                return new NumberIDT(0.0f);
            case "string":
                return new StringIDT("");
            case "character":
                return new CharIDT(' ');
            default:
                // For object types, return a ReferenceIDT with null
                ReferenceIDT ref = new ReferenceIDT();
                ref.refersTo = Optional.empty();
                return ref;
        }
    }
}
