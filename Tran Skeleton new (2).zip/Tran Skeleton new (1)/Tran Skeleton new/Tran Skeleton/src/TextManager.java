public class TextManager {
    private String text;
    private int position;

    // Initializer
    public TextManager(String input) {
        this.text = input;
        this.position = 0;
    }

    // Check if we reached the end
    public boolean isAtEnd() {
        return position >= text.length();
    }

    // Peek the current character
    public char peekCharacter() {
        if (isAtEnd()) {
            return '\0';  // Return null character if at the end
        }
        return text.charAt(position);
    }

    // Peek a character at a given distance
    public char peekCharacter(int distance) {
        int peekPosition = position + distance;
        if (peekPosition >= text.length()) {
            return '\0';  // Return null character if the peek is beyond the text
        }
        return text.charAt(peekPosition);
    }

    // Get the current character and move to the next one
    public char getCharacter() {
        if (isAtEnd()) {
            throw new IndexOutOfBoundsException("Reached the end of the text.");
        }
        return text.charAt(position++);
    }
}
