import java.util.List;
import java.util.Optional;

public class TokenManager {

    private List<Token> tokens;

    public TokenManager(List<Token> tokens) {
        this.tokens = tokens;
    }

    public boolean done() {
        return tokens.isEmpty();
    }

    public Optional<Token> matchAndRemove(Token.TokenTypes expectedType) throws SyntaxErrorException {
        if (peek(0).isPresent() && peek(0).get().getType() == expectedType) {
            return Optional.of(tokens.removeFirst());
        }
        return Optional.empty();
    }


    public Optional<Token> peek(int i) {
        if (i >= 0 && i < tokens.size()) {
            return Optional.of(tokens.get(i));
        }
        return Optional.empty();
    }

    public boolean nextTwoTokensMatch(Token.TokenTypes first, Token.TokenTypes second) {
        if (tokens.size() < 2) return false;
        return tokens.get(0).getType() == first && tokens.get(1).getType() == second;
    }

    public int getCurrentLine() {
        if (!tokens.isEmpty()) {
            return tokens.get(0).getLineNumber(); // Correct method name
        }
        return -1;
    }

    public int getCurrentColumnNumber() {
        if (!tokens.isEmpty()) {
            return tokens.get(0).getColumnNumber(); // Correct method name
        }
        return -1;
    }
}
