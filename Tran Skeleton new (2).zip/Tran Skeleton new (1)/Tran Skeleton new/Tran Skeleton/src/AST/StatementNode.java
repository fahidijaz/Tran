package AST;

public interface StatementNode extends Node {
}
